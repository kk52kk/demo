<?php
// Запускаем сессию для проверки авторизации
session_start();

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    // Если не авторизован, переадресация на страницу входа
    header("Location: login.php");
    exit;
}

// Заглушка — данные пользователя из сессии
$user_name = $_SESSION['user_name'] ?? 'Пользователь';

// Заглушка — список заявок пользователя (обычно из базы)
$requests = [
    ['car_brand' => 'Toyota', 'car_model' => 'Camry', 'test_date' => '2025-07-01', 'test_time' => '15:00', 'status' => 'одобрено'],
    ['car_brand' => 'BMW', 'car_model' => 'X5', 'test_date' => '2025-07-03', 'test_time' => '11:00', 'status' => 'выполнено'],
];

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>Добро пожаловать, <?= htmlspecialchars($user_name) ?>!</h2>

    <nav class="mb-3">
        <a href="index.php" class="btn btn-outline-primary">Главная</a>
        <a href="create_request.php" class="btn btn-success">Создать заявку</a>
        <a href="logout.php" class="btn btn-secondary">Выйти</a>
    </nav>

    <h4>Ваши заявки:</h4>

    <?php if (count($requests) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Марка</th>
                    <th>Модель</th>
                    <th>Дата</th>
                    <th>Время</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['car_brand']) ?></td>
                        <td><?= htmlspecialchars($r['car_model']) ?></td>
                        <td><?= htmlspecialchars($r['test_date']) ?></td>
                        <td><?= htmlspecialchars($r['test_time']) ?></td>
                        <td><?= htmlspecialchars($r['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Заявок пока нет.</p>
    <?php endif; ?>
</div>

</body>
</html>
