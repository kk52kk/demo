<?php
session_start();

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Подключение к базе данных
$host = 'localhost';
$dbname = 'demo';  // ЗАМЕНИ на имя БД на экзамене
$username = 'root';
$password = ''; // или 'root', если ты на Mac

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Получаем данные из формы
$address         = $_POST['address'] ?? '';
$phone           = $_POST['phone'] ?? '';
$email           = $_POST['email'] ?? '';
$test_date       = $_POST['test_date'] ?? '';
$test_time       = $_POST['test_time'] ?? '';
$car_brand       = $_POST['car_brand'] ?? '';
$car_model       = $_POST['car_model'] ?? '';
$license_series  = $_POST['license_series'] ?? '';
$license_number  = $_POST['license_number'] ?? '';
$license_date    = $_POST['license_date'] ?? '';
$payment_type    = $_POST['payment_type'] ?? '';
$user_id         = $_SESSION['user_id'];

// Вставка заявки в таблицу requests
$sql = "INSERT INTO requests 
        (user_id, address, phone, email, test_date, test_time, car_brand, car_model, license_series, license_number, license_date, payment_type, status, created_at)
        VALUES 
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ожидание', NOW())";

$stmt = $pdo->prepare($sql);
$success = $stmt->execute([
    $user_id, $address, $phone, $email, $test_date, $test_time,
    $car_brand, $car_model, $license_series, $license_number,
    $license_date, $payment_type
]);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заявка отправлена</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

    <?php if ($success): ?>
        <div class="alert alert-success">
            Ваша заявка успешно отправлена!
        </div>
    <?php else: ?>
        <div class="alert alert-danger">
            Произошла ошибка при отправке заявки. Пожалуйста, попробуйте снова.
        </div>
    <?php endif; ?>

    <a href="lk.php" class="btn btn-primary">Вернуться в личный кабинет</a>

</body>
</html>
