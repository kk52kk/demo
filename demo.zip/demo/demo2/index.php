<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1>Портал "Едем, но это не точно"</h1>
    <!-- Ссылки на регистрацию, вход и админку -->
    <a href="register.php" class="btn btn-primary">Регистрация</a>
    <a href="login.php" class="btn btn-success">Войти</a>
    <a href="admin.php" class="btn btn-warning">Админка</a>
</body>
</html>
