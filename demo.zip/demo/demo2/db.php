<?php
// db.php — подключение к базе данных
$host = 'localhost'; // имя хоста (обычно localhost)
$db = 'edem_no_tochno'; // имя базы данных (заполняется на экзамене)
$user = 'root'; // имя пользователя БД
$pass = ''; // пароль (по умолчанию пустой на локалке)
$charset = 'utf8mb4'; // кодировка

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // режим ошибок
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // тип выборки
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options); // создаём PDO-соединение
} catch (PDOException $e) {
    echo "Ошибка подключения к базе данных!";
    exit;
}
