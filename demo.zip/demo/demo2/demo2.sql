-- Создаем базу данных (если нужно, поменяйте имя)
CREATE DATABASE IF NOT EXISTS edem_no_tochno CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edem_no_tochno;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица заявок на тест-драйв
CREATE TABLE requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    car_brand VARCHAR(50) NOT NULL,
    car_model VARCHAR(50) NOT NULL,
    test_date DATE NOT NULL,
    test_time TIME NOT NULL,
    address VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    driver_license_series VARCHAR(10) NOT NULL,
    driver_license_number VARCHAR(20) NOT NULL,
    driver_license_date DATE NOT NULL,
    payment_type ENUM('наличными', 'банковская карта') NOT NULL,
    status ENUM('одобрено', 'выполнено', 'отклонено') DEFAULT 'одобрено',
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
