<?php
require 'db.php';
session_start();

// Проверяем, что пользователь авторизован
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $address = $_POST['address'];
    $contact_phone = $_POST['contact_phone'];
    $test_date = $_POST['test_date'];
    $test_time = $_POST['test_time'];
    $driver_license = $_POST['driver_license'];
    $car_brand = $_POST['car_brand'];
    $car_model = $_POST['car_model'];

    // Вставляем заявку в таблицу requests
    $stmt = $pdo->prepare("INSERT INTO requests (user_id, address, contact_phone, test_date, test_time, driver_license, car_brand, car_model, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Новая', NOW())");
    $stmt->execute([$_SESSION['user_id'], $address, $contact_phone, $test_date, $test_time, $driver_license, $car_brand, $car_model]);

    echo "<p>Заявка успешно отправлена. <a href='lk.php'>Вернуться в личный кабинет</a></p>";
}
