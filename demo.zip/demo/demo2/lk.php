<?php
require 'db.php';
session_start();

// Проверяем, что пользователь авторизован
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Получаем заявки пользователя из БД
$stmt = $pdo->prepare("SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Добро пожаловать, <?= htmlspecialchars($_SESSION['user_name']) ?>!</h2>

    <div class="mb-3">
        <a href="create_request.php" class="btn btn-success">Создать новую заявку</a>
        <a href="logout.php" class="btn btn-secondary">Выйти</a>
    </div>

    <h4>Ваши заявки:</h4>

    <?php if (count($requests) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Марка</th>
                    <th>Модель</th>
                    <th>Дата</th>
                    <th>Время</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['car_brand']) ?></td>
                        <td><?= htmlspecialchars($r['car_model']) ?></td>
                        <td><?= htmlspecialchars($r['test_date']) ?></td>
                        <td><?= htmlspecialchars($r['test_time']) ?></td>
                        <td><?= htmlspecialchars($r['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Заявок пока нет.</p>
    <?php endif; ?>
</body>
</html>
