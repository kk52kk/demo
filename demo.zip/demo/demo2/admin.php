<?php
require 'db.php';
session_start();

// Простейшая проверка администратора (на экзамене можно будет менять)
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    echo "Доступ запрещён!";
    exit;
}

// Получаем все заявки из БД
$stmt = $pdo->query("SELECT requests.*, users.full_name FROM requests JOIN users ON requests.user_id = users.id ORDER BY created_at DESC");
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админка</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Админка: заявки пользователей</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Пользователь</th>
                <th>Марка</th>
                <th>Модель</th>
                <th>Дата</th>
                <th>Время</th>
                <th>Статус</th>
                <th>Дата создания</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['full_name']) ?></td>
                    <td><?= htmlspecialchars($r['car_brand']) ?></td>
                    <td><?= htmlspecialchars($r['car_model']) ?></td>
                    <td><?= htmlspecialchars($r['test_date']) ?></td>
                    <td><?= htmlspecialchars($r['test_time']) ?></td>
                    <td><?= htmlspecialchars($r['status']) ?></td>
                    <td><?= htmlspecialchars($r['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
