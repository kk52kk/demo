<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $phone     = $_POST['phone'];
    $email     = $_POST['email'];
    $login     = $_POST['login'];
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Вставляем нового пользователя в таблицу users
    $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, email, login, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$full_name, $phone, $email, $login, $password]);

    echo "<p>Регистрация прошла успешно. <a href='login.php'>Войти</a></p>";
}
