<?php
session_start();

// Проверяем, что пользователь авторизован
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Создать заявку</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Создание заявки на тест-драйв</h2>
    <form action="create_request_process.php" method="post">
        <div class="mb-3">
            <label>Адрес:</label>
            <input type="text" name="address" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Контактный телефон:</label>
            <input type="text" name="contact_phone" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Дата тест-драйва:</label>
            <input type="date" name="test_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Время тест-драйва:</label>
            <input type="time" name="test_time" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Водительское удостоверение (серия):</label>
            <input type="text" name="driver_license" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Марка автомобиля:</label>
            <input type="text" name="car_brand" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Модель автомобиля:</label>
            <input type="text" name="car_model" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Отправить заявку</button>
    </form>
</body>
</html>
