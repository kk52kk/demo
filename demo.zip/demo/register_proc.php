<?php
session_start();

// Подключение к БД
$host = 'localhost';
$dbname = 'your_database_name'; // ← Замени на имя БД
$username = 'root';
$password = ''; // ← Может быть 'root' или другой на экзамене

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Получение данных из формы
$login    = trim($_POST['login'] ?? '');
$password = $_POST['password'] ?? '';
$full_name = trim($_POST['full_name'] ?? '');
$phone    = trim($_POST['phone'] ?? '');
$email    = trim($_POST['email'] ?? '');

// Валидация
$errors = [];

if (strlen($login) < 3) {
    $errors[] = "Логин должен содержать минимум 3 символа.";
}

if (strlen($password) < 6) {
    $errors[] = "Пароль должен содержать минимум 6 символов.";
}

if (!preg_match('/^[А-Яа-яЁё\s]+$/u', $full_name)) {
    $errors[] = "ФИО должно содержать только кириллицу и пробелы.";
}

if (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
    $errors[] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Некорректный email.";
}

// Проверка уникальности логина
$stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
$stmt->execute([$login]);
if ($stmt->fetch()) {
    $errors[] = "Такой логин уже существует.";
}

if (!empty($errors)) {
    // Если ошибки есть — покажем их
    echo "<h3>Ошибки при регистрации:</h3><ul>";
    foreach ($errors as $e) {
        echo "<li>" . htmlspecialchars($e) . "</li>";
    }
    echo '</ul><a href="register.php">← Назад к регистрации</a>';
    exit;
}

// Хеширование пароля
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Сохраняем пользователя
$stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, phone, email, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
$success = $stmt->execute([$login, $hashed_password, $full_name, $phone, $email]);

if ($success) {
    echo "<div style='color: green;'>Регистрация успешна!</div>";
    echo '<a href="login.php">Перейти к входу →</a>';
} else {
    echo "<div style='color: red;'>Ошибка при регистрации. Попробуйте позже.</div>";
}
