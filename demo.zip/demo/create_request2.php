<?php
session_start();

// Проверка авторизации пользователя
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Новая заявка</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

    <h2>Создание новой заявки</h2>

    <form action="submit_request.php" method="post">
        <!-- Адрес пользователя -->
        <div class="mb-3">
            <label for="address" class="form-label">Адрес</label>
            <input type="text" class="form-control" name="address" id="address" required>
        </div>

        <!-- Контактные данные -->
        <div class="mb-3">
            <label for="phone" class="form-label">Телефон</label>
            <input type="text" class="form-control" name="phone" id="phone" placeholder="+7(XXX)-XXX-XX-XX" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Электронная почта</label>
            <input type="email" class="form-control" name="email" id="email" required>
        </div>

        <!-- Дата и время -->
        <div class="mb-3">
            <label for="test_date" class="form-label">Дата тест-драйва</label>
            <input type="date" class="form-control" name="test_date" id="test_date" required>
        </div>

        <div class="mb-3">
            <label for="test_time" class="form-label">Время</label>
            <input type="time" class="form-control" name="test_time" id="test_time" required>
        </div>

        <!-- Автомобиль -->
        <div class="mb-3">
            <label for="car_brand" class="form-label">Марка автомобиля</label>
            <select name="car_brand" id="car_brand" class="form-select" required>
                <option value="">Выберите марку</option>
                <option value="Toyota">Toyota</option>
                <option value="BMW">BMW</option>
                <option value="Hyundai">Hyundai</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="car_model" class="form-label">Модель автомобиля</label>
            <select name="car_model" id="car_model" class="form-select" required>
                <option value="">Выберите модель</option>
                <option value="Camry">Camry</option>
                <option value="Corolla">Corolla</option>
                <option value="X5">X5</option>
                <option value="Sonata">Sonata</option>
                <option value="Elantra">Elantra</option>
            </select>
        </div>

        <!-- Водительское удостоверение -->
        <div class="mb-3">
            <label for="license_series" class="form-label">Серия ВУ</label>
            <input type="text" class="form-control" name="license_series" id="license_series" required>
        </div>

        <div class="mb-3">
            <label for="license_number" class="form-label">Номер ВУ</label>
            <input type="text" class="form-control" name="license_number" id="license_number" required>
        </div>

        <div class="mb-3">
            <label for="license_date" class="form-label">Дата выдачи ВУ</label>
            <input type="date" class="form-control" name="license_date" id="license_date" required>
        </div>

        <!-- Способ оплаты -->
        <div class="mb-3">
            <label for="payment_type" class="form-label">Тип оплаты</label>
            <select name="payment_type" id="payment_type" class="form-select" required>
                <option value="">Выберите способ оплаты</option>
                <option value="наличными">Наличными</option>
                <option value="банковская карта">Банковская карта</option>
            </select>
        </div>

        <!-- Кнопки -->
        <button type="submit" class="btn btn-success">Отправить заявку</button>
        <a href="lk.php" class="btn btn-secondary">Назад</a>
    </form>

</body>
</html>
