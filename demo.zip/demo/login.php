<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход</title>

    <!-- Подключаем кастомные стили -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Подключаем Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <!-- Заголовок страницы -->
    <h2>Вход</h2>

    <!-- Навигация -->
    <nav class="mb-3">
        <a href="index.php" class="btn btn-outline-primary">Главная</a>
        <a href="register.php" class="btn btn-outline-success">Регистрация</a>
    </nav>

    <!-- Форма входа -->
    <form method="post" action="lk.php">
        <!-- Логин -->
        <div class="mb-3">
            <label>Логин:</label>
            <input type="text" name="login" class="form-control" required>
        </div>

        <!-- Пароль -->
        <div class="mb-3">
            <label>Пароль:</label>
            <input type="password" name="password" class="form-control" required minlength="6">
        </div>

        <!-- Кнопка отправки -->
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
</div>

</body>
</html>
