<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная - Едем, но это не точно</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h1>Портал «Едем, но это не точно»</h1>

    <nav class="mb-3">
        <a href="index.php" class="btn btn-outline-primary">Главная</a>
        <a href="register.php" class="btn btn-outline-success">Регистрация</a>
        <a href="login.php" class="btn btn-outline-secondary">Вход</a>
        <a href="lk.php" class="btn btn-outline-info">Личный кабинет</a>
        <a href="admin.php" class="btn btn-outline-danger">Админка</a>
    </nav>

    <p>Добро пожаловать! Это портал для подачи заявок на тест-драйв автомобилей. Пройдите регистрацию, авторизуйтесь и подайте заявку.</p>
</div>

</body>
</html>
