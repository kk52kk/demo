<?php
session_start();

// Проверяем авторизацию пользователя
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Заглушка — список доступных марок и моделей автомобилей
$car_list = [
    'Toyota' => ['Camry', 'Corolla'],
    'BMW' => ['X5', 'X3']
];

// Можно позже добавить обработку отправки формы через POST, сейчас просто форма
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Создание заявки</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // JS для динамического обновления моделей в зависимости от марки
        function updateModels() {
            const carList = <?php echo json_encode($car_list); ?>;
            const brandSelect = document.getElementById('car_brand');
            const modelSelect = document.getElementById('car_model');

            // Очищаем модели
            modelSelect.innerHTML = '';

            // Получаем выбранную марку
            const selectedBrand = brandSelect.value;

            if (selectedBrand in carList) {
                carList[selectedBrand].forEach(function(model) {
                    let option = document.createElement('option');
                    option.value = model;
                    option.text = model;
                    modelSelect.appendChild(option);
                });
            }
        }
    </script>
</head>
<body>

<div class="container">
    <h2>Создать заявку на тест-драйв</h2>

    <nav class="mb-3">
        <a href="lk.php" class="btn btn-outline-primary">Личный кабинет</a>
        <a href="logout.php" class="btn btn-secondary">Выйти</a>
    </nav>

    <form method="post" action="#">
        <!-- Адрес -->
        <div class="mb-3">
            <label>Адрес:</label>
            <input type="text" name="address" class="form-control" required placeholder="Ваш адрес">
        </div>

        <!-- Контактный телефон -->
        <div class="mb-3">
            <label>Телефон:</label>
            <input type="tel" name="phone" class="form-control" required pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" placeholder="+7(900)-123-45-67">
        </div>

        <!-- Дата -->
        <div class="mb-3">
            <label>Дата тест-драйва:</label>
            <input type="date" name="test_date" class="form-control" required>
        </div>

        <!-- Время -->
        <div class="mb-3">
            <label>Время тест-драйва:</label>
            <input type="time" name="test_time" class="form-control" required>
        </div>

        <!-- Серия и номер водительского удостоверения -->
        <div class="mb-3">
            <label>Серия и номер водительского удостоверения:</label>
            <input type="text" name="driver_license" class="form-control" required placeholder="1234 567890">
        </div>

        <!-- Марка автомобиля -->
        <div class="mb-3">
            <label>Марка автомобиля:</label>
            <select id="car_brand" name="car_brand" class="form-select" required onchange="updateModels()">
                <option value="" disabled selected>Выберите марку</option>
                <?php foreach ($car_list as $brand => $models): ?>
                    <option value="<?= htmlspecialchars($brand) ?>"><?= htmlspecialchars($brand) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Модель автомобиля -->
        <div class="mb-3">
            <label>Модель автомобиля:</label>
            <select id="car_model" name="car_model" class="form-select" required>
                <option value="" disabled selected>Сначала выберите марку</option>
            </select>
        </div>

        <!-- Тип оплаты -->
        <div class="mb-3">
            <label>Тип оплаты:</label>
            <select name="payment_type" class="form-select" required>
                <option value="" disabled selected>Выберите тип оплаты</option>
                <option value="cash">Наличными</option>
                <option value="card">Банковской картой</option>
            </select>
        </div>

        <!-- Кнопка отправки -->
        <button type="submit" class="btn btn-success">Отправить заявку</button>
    </form>
</div>

<script>
    // Обновляем модели при загрузке страницы (если выбрана марка)
    updateModels();
</script>

</body>
</html>
