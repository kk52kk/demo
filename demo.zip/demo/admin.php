<?php
session_start();

// Жёсткие логин и пароль администратора
$admin_login = 'avto2024';
$admin_password = 'poehali';

// Проверка входа (если форма отправлена)
if (isset($_POST['login']) && isset($_POST['password'])) {
    if ($_POST['login'] === $admin_login && $_POST['password'] === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error = "Неверный логин или пароль";
    }
}

// Проверка авторизации администратора
if (!isset($_SESSION['admin_logged_in'])) {
    // Если не авторизован — показываем форму входа
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Вход администратора</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
    <div class="container mt-5" style="max-width:400px;">
        <h2>Вход администратора</h2>
        <?php if (!empty($error)) echo '<div class="alert alert-danger">' . htmlspecialchars($error) . '</div>'; ?>
        <form method="post">
            <div class="mb-3">
                <label>Логин</label>
                <input type="text" name="login" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Пароль</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Войти</button>
            <a href="index.php" class="btn btn-secondary ms-2">Назад</a>
        </form>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// Заглушка — заявки (в реале из БД)
$requests = [
    ['id'=>1,'fio'=>'Иван Иванов','phone'=>'+7(900)-111-22-33','email'=>'ivan@example.com','address'=>'ул. Ленина, 5','car_brand'=>'Toyota','car_model'=>'Camry','test_date'=>'2025-07-01','test_time'=>'15:00','payment_type'=>'наличными','status'=>'ожидает','reject_reason'=>''],
    ['id'=>2,'fio'=>'Петр Петров','phone'=>'+7(900)-222-33-44','email'=>'petr@example.com','address'=>'пр. Мира, 10','car_brand'=>'BMW','car_model'=>'X5','test_date'=>'2025-07-03','test_time'=>'11:00','payment_type'=>'банковская карта','status'=>'одобрено','reject_reason'=>''],
];

// Обработка смены статуса (если форма отправлена)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'], $_POST['status'])) {
    foreach ($requests as &$r) {
        if ($r['id'] == $_POST['request_id']) {
            $r['status'] = $_POST['status'];
            if ($r['status'] === 'отклонено') {
                $r['reject_reason'] = $_POST['reject_reason'] ?? '';
            } else {
                $r['reject_reason'] = '';
            }
            break;
        }
    }
    unset($r);
    // Обычно тут обновляем в базе, но пока заглушка
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        textarea {resize: vertical;}
    </style>
</head>
<body>

<div class="container mt-4">
    <h2>Панель администратора</h2>
    <a href="logout.php" class="btn btn-secondary mb-3">Выйти</a>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ФИО</th>
            <th>Телефон</th>
            <th>Email</th>
            <th>Адрес</th>
            <th>Авто</th>
            <th>Дата и время</th>
            <th>Оплата</th>
            <th>Статус</th>
            <th>Причина отклонения</th>
            <th>Действия</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($requests as $r): ?>
            <tr>
                <td><?=htmlspecialchars($r['fio'])?></td>
                <td><?=htmlspecialchars($r['phone'])?></td>
                <td><?=htmlspecialchars($r['email'])?></td>
                <td><?=htmlspecialchars($r['address'])?></td>
                <td><?=htmlspecialchars($r['car_brand'] . ' ' . $r['car_model'])?></td>
                <td><?=htmlspecialchars($r['test_date'] . ' ' . $r['test_time'])?></td>
                <td><?=htmlspecialchars($r['payment_type'])?></td>
                <td><?=htmlspecialchars($r['status'])?></td>
                <td><?=htmlspecialchars($r['reject_reason'])?></td>
                <td>
                    <form method="post" style="min-width: 220px;">
                        <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                        <select name="status" class="form-select mb-1" required onchange="toggleReason(this, this.nextElementSibling)">
                            <option value="ожидает" <?= $r['status']=='ожидает'?'selected':'' ?>>Ожидает</option>
                            <option value="одобрено" <?= $r['status']=='одобрено'?'selected':'' ?>>Одобрено</option>
                            <option value="выполнено" <?= $r['status']=='выполнено'?'selected':'' ?>>Выполнено</option>
                            <option value="отклонено" <?= $r['status']=='отклонено'?'selected':'' ?>>Отклонено</option>
                        </select>
                        <textarea name="reject_reason" class="form-control" rows="2" placeholder="Причина отклонения" style="display: <?= $r['status']=='отклонено' ? 'block' : 'none' ?>;"><?=htmlspecialchars($r['reject_reason'])?></textarea>
                        <button type="submit" class="btn btn-primary btn-sm mt-1">Сохранить</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
    // Показываем/скрываем textarea с причиной отклонения
    function toggleReason(select, textarea) {
        if (select.value === 'отклонено') {
            textarea.style.display = 'block';
            textarea.required = true;
        } else {
            textarea.style.display = 'none';
            textarea.required = false;
            textarea.value = '';
        }
    }
</script>

</body>
</html>
