<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>

    <!-- Подключаем кастомные стили -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Подключаем Bootstrap из CDN для стилизации -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <!-- Заголовок страницы -->
    <h2>Регистрация</h2>

    <!-- Навигационные ссылки -->
    <nav class="mb-3">
        <a href="index.php" class="btn btn-outline-primary">Главная</a>
        <a href="login.php" class="btn btn-outline-secondary">Вход</a>
    </nav>

    <!-- Форма регистрации пользователя -->
    <form method="post" action="#">
        <!-- Поле для ФИО -->
        <div class="mb-3">
            <label>ФИО:</label>
            <input type="text" name="full_name" class="form-control" required
                   pattern="[А-Яа-яЁё\s]+" placeholder="Иванов Иван Иванович">
        </div>

        <!-- Поле для телефона -->
        <div class="mb-3">
            <label>Телефон:</label>
            <input type="tel" name="phone" class="form-control" required
                   pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" placeholder="+7(900)-123-45-67">
        </div>

        <!-- Поле для электронной почты -->
        <div class="mb-3">
            <label>Email:</label>
            <input type="email" name="email" class="form-control" required placeholder="example@mail.ru">
        </div>

        <!-- Поле для логина -->
        <div class="mb-3">
            <label>Логин:</label>
            <input type="text" name="login" class="form-control" required>
        </div>

        <!-- Поле для пароля -->
        <div class="mb-3">
            <label>Пароль:</label>
            <input type="password" name="password" class="form-control" required minlength="6">
        </div>

        <!-- Кнопка отправки формы -->
        <button type="submit" class="btn btn-success">Зарегистрироваться</button>
    </form>
</div>

</body>
</html>
